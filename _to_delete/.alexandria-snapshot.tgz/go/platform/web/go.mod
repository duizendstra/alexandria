module github.com/duizendstra/alexandria/go/platform/web

go 1.26

require (
	github.com/duizendstra/alexandria/go/platform/apierr v0.0.0
	github.com/stretchr/testify v1.10.0
)

require (
	github.com/davecgh/go-spew v1.1.1 // indirect
	github.com/pmezard/go-difflib v1.0.0 // indirect
	gopkg.in/yaml.v3 v3.0.1 // indirect
)

replace github.com/duizendstra/alexandria/go/platform/apierr => ../apierr
