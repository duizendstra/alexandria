// Copyright 2026 Jasper Duizendstra. All rights reserved.
// Licensed under the Apache License, Version 2.0.
// SPDX-License-Identifier: Apache-2.0.

package sloggcp_test

import (
	"context"
	"errors"
	"fmt"
	"log/slog"
	"net/http"
	"os"
	"time"

	sloggcp "github.com/duizendstra/alexandria/go/slog-gcp"
)

var errConnectionRefused = errors.New("connection refused")

func ExampleSetup() {
	// Setup configures the default slog logger for GCP Cloud Logging.
	// On Cloud Run (K_SERVICE set), outputs JSON; locally, outputs text.
	sloggcp.Setup()

	slog.Info("server started", slog.Int("port", 8080))
	// Output is environment-dependent.
}

func ExampleNewHandler() {
	inner := slog.NewJSONHandler(os.Stdout, &slog.HandlerOptions{
		ReplaceAttr: sloggcp.GCPReplaceAttr,
	})

	// nil resolver disables trace injection; empty projectID auto-detects.
	handler := sloggcp.NewHandler(inner, nil, "my-project", sloggcp.WithEventID(false))
	logger := slog.New(handler)
	logger.Info("hello")
}

func ExampleErrorAttrs() {
	err := errConnectionRefused
	attrs := sloggcp.ErrorAttrs(err, sloggcp.ServiceContextFromEnv())

	// attrs contains @type, serviceContext, stack_trace, and error fields
	// for Cloud Error Reporting integration.
	fmt.Println(len(attrs))
	// Output:
	// 4
}

func ExampleWithTrace() {
	ctx := sloggcp.WithTrace(context.Background())
	// Use ctx with any slog call — trace ID is injected automatically.
	slog.InfoContext(ctx, "job started")
}

func ExampleHTTPRequestAttr() {
	reqAttr := sloggcp.HTTPRequestAttr(&sloggcp.HTTPRequest{
		Method:  http.MethodGet,
		URL:     "/api/health",
		Status:  200,
		Latency: 42 * time.Millisecond,
	})
	_ = reqAttr
}

func ExampleWithLevelVar() {
	var level slog.LevelVar
	level.Set(slog.LevelInfo)

	// Pass the LevelVar to Setup for dynamic control.
	// In production: sloggcp.Setup(sloggcp.WithLevelVar(&level)).
	_ = &level
}
